<?php
	require_once('../frame.php');
	$province = $_REQUEST['province'];
	$city = $_REQUEST['city'];
	$position = $_REQUEST['position'];
	$date = $_REQUEST['date'];
	$read = $_REQUEST['read'];
	
	$db = get_db();
	$sql = "select t1.*,t2.name as p_name,t3.name as c_name from hoau_employ t1 join hoau_position t2 on t1.position_id=t2.id join hoau_province t3 on t1.city_id=t3.id where 1=1";
	if($city!=''){
		$sql = $sql." and city_id=".$city;
	}
	if($position!=''){
		$sql = $sql." and position_id=".$position;
	}
	if($date!=''){
		$sql = $sql." and date>'".$date." 00:00:00' and date<'".$date." 23:59:59'";
	}
	if($read!=''){
		$sql = $sql." and is_read=".$read;
	}
	$sql = $sql." order by t1.date desc";
	$records = $db->paginate($sql,20);
	$count = count($records);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv=Content-Type content="text/html; charset=utf-8">
	<meta http-equiv=Content-Language content=zh-CN>
	<title>天地华宇</title>
	<?php 
		css_include_tag('admin','jquery_ui');
		use_jquery_ui();
		js_include_tag('admin_pub');
	?>
</head>
<body style="background:#E1F0F7">
	<table width="795" border="0">
		<tr class="tr1">
			<td colspan="5" width="795">　简历管理　
				城市<select id="s_city">
					<option></option>
					<?php 
						$record = $db->query("select * from hoau_province where parent_id=0");
						$count2 = count($record);
						for($i=0;$i<$count2;$i++){
					?>
						<option <?php if($record[$i]->id==$province){?>selected="selected"<?php }?> value="<?php echo $record[$i]->id;?>"><?php echo $record[$i]->name;?></option>
					<?php }?>
				</select>
				<span id="show_city">
					<?php if($city!=''){
					?>
					<select id="city_id">
						<?php 
							$sql = "select * from hoau_province where parent_id>0 and parent_id=".$province;
							$record = $db->query($sql);
							$count2 = count($record);
							for($i=0;$i<$count2;$i++){
						?>
						<option <?php if($record[$i]->id==$city){?>selected="selected"<?php }?> value="<?php echo $record[$i]->id?>"><?php echo $record[$i]->name;?></option>
						<?php }?>
					</select>
					<?php }else{
					?>
					<span id="city_id"></span>
					<?php
					} ?>
				</span>　
				职位<select id="p_id">
					<option></option>
					<?php 
						$record = $db->query("select * from hoau_position");
						$count2 = count($record);
						for($i=0;$i<$count2;$i++){
					?>
						<option <?php if($record[$i]->id==$position){?>selected="selected"<?php }?> value="<?php echo $record[$i]->id;?>"><?php echo $record[$i]->name;?></option>
					<?php }?>
				</select>　
				时间<input type="text" value="<?php echo $date;?>" class="date_jquery" id="date" style="width:100px;">　
				是否已读<select id="r_id">
					<option></option>
					<option <?php if($read=="0"){?>selected="selected"<?php }?> value="0">未读</option>
					<option <?php if($read=="1"){?>selected="selected"<?php }?> value="1">已读</option>
				</select>　
				<button type="button" id="submit">提交</button>
			</td>
		</tr>
		
		<tr class="tr2">
			<td width="200">职位名</td><td width="100">投递城市</td><td width="200">时间</td><td width="195">操作</td><td width="100">是否已读</td>
		</tr>
		<?php for($i=0;$i<$count;$i++){?>
		<tr class="tr3" id="<?php echo $records[$i]->id;?>">
			<td><?php echo $records[$i]->p_name;?></td>
			<td><?php echo $records[$i]->c_name;?></td>
			<td><?php echo date_format($records[$i]->date,"Y-m-d H:i:s");?></td>
			<td>	
				<a href="<?php echo $records[$i]->url;?>" class="read" name="<?php echo $records[$i]->id;?>" style="color:#000000; text-decoration:none">查看简历</a> 
			</td>
			<td id="set_read_<?php echo $records[$i]->id;?>"><?php if($records[$i]->is_read==1){echo "已读";}else{echo "未读";}?></td>
		</tr>
		<? }?>
	</table>
	<input type="hidden" id="db_table" value="hoau_position">
	<div class="div_box">
		<table width="795" border="0">
			<tr colspan="5" class=tr3>
				<td><?php paginate();?><span style="cursor:pointer;" id="zip_download">批量下载</span></td>
			</tr>
		</table>
	</div>
</body>
</html>

<script>
	$(function(){
		$(".read").click(function(){
			$.post('/employ/set_read.php',{'id':$(this).attr('name')},function(data){
				$("#set_read_"+data).html('已读');
			});
		})
		
		$("#s_city").change(function(){
			$.post('/employ/show_city.php',{'id':$(this).val()},function(data){
				$("#show_city").html(data);
			});
		})
		
		$(".date_jquery").datepicker(
			{
				monthNames:['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'],
				dayNames:["星期日","星期一","星期二","星期三","星期四","星期五","星期六"],
				dayNamesMin:["日","一","二","三","四","五","六"],
				dayNamesShort:["星期日","星期一","星期二","星期三","星期四","星期五","星期六"],
				dateFormat: 'yy-mm-dd'
			}
		);
		var province = $("#s_city").val();
		var city = $("#city_id").val();
		var position = $("#p_id").val();
		var date = $("#date").val();
		var read = $("#r_id").val();
		
		$("#submit").click(function(){
			window.location.href="?province="+province+"&city="+city+"&position="+position+"&date="+date+"&read="+read;
		});
		
		$("#zip_download").click(function(){
			$.post('zip_download.php',{'province':province,'city':city,'position':position,'date':date,'read':read},function(data){
				
			})
		})
	})
</script>
